GESTOPRO360 Brand Kit

Contenuto:
- Icona principale: gestopro360.ico
- Sorgente vettoriale icona: gestopro360-ico.svg
- Preview icona: gestopro360-ico.png
- Variante combo approvata: gestopro360-ico-v3-combo.{ico,png}
- Logo grande vettoriale: logo-grande-gestopro360.svg
- Logo concept 4 vettoriale: logo-gestopro360-04.svg
- Pacchetto web/app completo: cartella app-icons/

Uso rapido web:
- usa app-icons/favicon.ico
- collega app-icons/site.webmanifest
- usa app-icons/apple-touch-icon.png per iOS
