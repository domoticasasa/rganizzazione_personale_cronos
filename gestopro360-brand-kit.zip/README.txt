GESTOPRO360 Brand Kit

Contenuto principale:
- Icona principale aggiornata: gestopro360.ico
- Sorgente vettoriale icona: gestopro360-ico.svg
- Preview icona: gestopro360-ico.png
- Variante combo: gestopro360-ico-v3-combo.{ico,png}
- Variante wordmark interna (GESTOPRO): gestopro360-ico-v4-gestopro.{ico,png}
- Logo grande vettoriale: logo-grande-gestopro360.svg
- Logo concept 4 vettoriale: logo-gestopro360-04.svg
- Pacchetto web/app completo: cartella app-icons/
